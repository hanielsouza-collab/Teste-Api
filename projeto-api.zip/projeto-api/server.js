const express = require("express")
const app = express()

const filmeRoutes = require("./src/routes/filmeRoutes")

app.use(express.json())

app.use("/", filmeRoutes)

app.listen(3000, () => {
    console.log("API rodando em http://localhost:3000")
})