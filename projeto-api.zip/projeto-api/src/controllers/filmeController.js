const filmes = require("../database/filmes")

const listar = (req, res) => {
    res.json(filmes)
}

const buscar = (req, res) => {
    const id = req.params.id
    const filme = filmes.find(f => f.id == id)

    res.json(filme)
}

const cadastrar = (req, res) => {
    const novo = req.body
    filmes.push(novo)

    res.json({ mensagem: "Filme cadastrado", filme: novo })
}

const atualizar = (req, res) => {
    const id = req.params.id
    const dados = req.body

    const index = filmes.findIndex(f => f.id == id)

    filmes[index] = { id: Number(id), ...dados }

    res.json({ mensagem: "Filme atualizado" })
}

const remover = (req, res) => {
    const id = req.params.id

    const index = filmes.findIndex(f => f.id == id)

    filmes.splice(index, 1)

    res.json({ mensagem: "Filme removido" })
}

module.exports = {
    listar,
    buscar,
    cadastrar,
    atualizar,
    remover
}