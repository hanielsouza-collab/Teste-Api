const filmes = [
    { id: 1, nome: "Avatar", categoria: "Ficção" },
    { id: 2, nome: "Vingadores", categoria: "Ação" },
    { id: 3, nome: "Batman", categoria: "Ação" },
    { id: 4, nome: "Titanic", categoria: "Romance" },
    { id: 5, nome: "Interestelar", categoria: "Ficção" },
    { id: 6, nome: "Corra!", categoria: "Suspense" },
    { id: 7, nome: "Shrek", categoria: "Animação" },
    { id: 8, nome: "Matrix", categoria: "Ficção" },
    { id: 9, nome: "Toy Story", categoria: "Animação" },
    { id: 10, nome: "Joker", categoria: "Drama" }
]

module.exports = filmes